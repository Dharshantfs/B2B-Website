'use client'

import { useAuth } from '@/context/AuthContext'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'

export default function AdminDashboard() {
  const { user, isAuthenticated, isLoading } = useAuth()
  const router = useRouter()
  const [stats, setStats] = useState({
    totalOrders: 0,
    totalDesigns: 0,
    pendingDesigns: 0,
  })

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login')
    } else if (user && user.role !== 'admin') {
      router.push('/')
    }

    // Calculate stats
    let orders = 0
    let designs = 0
    let pending = 0

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i)
      if (key?.startsWith('orders_')) {
        const orderList = JSON.parse(localStorage.getItem(key) || '[]')
        orders += orderList.length
      }
      if (key?.startsWith('designSubmissions_')) {
        const designList = JSON.parse(localStorage.getItem(key) || '[]')
        designs += designList.length
        pending += designList.filter((d: any) => d.status === 'pending').length
      }
    }

    setStats({ totalOrders: orders, totalDesigns: designs, pendingDesigns: pending })
  }, [isAuthenticated, isLoading, user, router])

  if (isLoading || !isAuthenticated || user?.role !== 'admin') {
    return <div className="container mx-auto px-4 py-12 text-center">Loading...</div>
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8">Admin Dashboard</h1>
      <div className="mb-6">
        <p className="text-gray-600">Welcome, {user?.email}</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-2">Total Orders</h3>
          <p className="text-3xl font-bold text-primary-600">{stats.totalOrders}</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-2">Total Designs</h3>
          <p className="text-3xl font-bold text-primary-600">{stats.totalDesigns}</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-2">Pending Designs</h3>
          <p className="text-3xl font-bold text-yellow-600">{stats.pendingDesigns}</p>
        </div>
      </div>
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold mb-4">System Overview</h2>
        <p className="text-gray-600">
          Admin dashboard for managing orders, designs, and system settings.
        </p>
      </div>
    </div>
  )
}

