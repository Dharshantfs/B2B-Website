export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8 text-center">About Us</h1>
      <div className="max-w-3xl mx-auto space-y-6 text-lg text-gray-700">
        <p>
          Welcome to Bagify Brandify Studio, your premier destination for high-quality bags
          and branding products. We are passionate about creating products that combine
          style, functionality, and durability.
        </p>
        <p>
          Our mission is to provide customers with premium products that enhance their
          daily lives. Whether you're a professional looking for the perfect briefcase,
          a traveler in need of reliable luggage, or someone who appreciates quality
          craftsmanship, we have something for everyone.
        </p>
        <h2 className="text-2xl font-bold mt-8 mb-4">Our Story</h2>
        <p>
          Founded with a vision to revolutionize the bag industry, Bagify Brandify Studio
          has been committed to excellence since day one. We carefully curate our product
          selection to ensure every item meets our high standards for quality and design.
        </p>
        <h2 className="text-2xl font-bold mt-8 mb-4">Why Choose Us</h2>
        <ul className="list-disc list-inside space-y-2">
          <li>Premium quality materials and craftsmanship</li>
          <li>Wide selection of styles and categories</li>
          <li>Competitive pricing</li>
          <li>Excellent customer service</li>
          <li>Fast and reliable shipping</li>
        </ul>
      </div>
    </div>
  )
}

