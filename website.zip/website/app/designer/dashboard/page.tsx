'use client'

import { useAuth } from '@/context/AuthContext'
import { useRouter } from 'next/navigation'
import { useEffect } from 'react'
import DesignRequests from '@/components/DesignRequests'

export default function DesignerDashboard() {
  const { user, isAuthenticated, isLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login')
    } else if (user && user.role !== 'designer') {
      router.push('/')
    }
  }, [isAuthenticated, isLoading, user, router])

  if (isLoading || !isAuthenticated || user?.role !== 'designer') {
    return <div className="container mx-auto px-4 py-12 text-center">Loading...</div>
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8">Designer Dashboard</h1>
      <div className="mb-6">
        <p className="text-gray-600">Welcome, {user?.email}</p>
      </div>
      <DesignRequests />
    </div>
  )
}

