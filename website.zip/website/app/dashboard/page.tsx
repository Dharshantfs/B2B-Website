'use client'

import { useAuth } from '@/context/AuthContext'
import { useRouter } from 'next/navigation'
import { useEffect } from 'react'
import OrderHistory from '@/components/OrderHistory'
import DesignSubmissions from '@/components/DesignSubmissions'
import { useCart } from '@/context/CartContext'

export default function CustomerDashboard() {
  const { user, isAuthenticated, isLoading } = useAuth()
  const { cart } = useCart()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login')
    }
  }, [isAuthenticated, isLoading, router])

  if (isLoading || !isAuthenticated || user?.role !== 'customer') {
    return <div className="container mx-auto px-4 py-12 text-center">Loading...</div>
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8">My Dashboard</h1>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-2">Active Cart</h3>
          <p className="text-3xl font-bold text-primary-600">{cart.length}</p>
          <p className="text-sm text-gray-600 mt-1">items in cart</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-2">Email</h3>
          <p className="text-sm text-gray-600">{user?.email}</p>
        </div>
      </div>
      <div className="space-y-8">
        <DesignSubmissions />
        <OrderHistory />
      </div>
    </div>
  )
}

