import { products } from '@/data/products'
import ProductDetail from '@/components/ProductDetail'
import { notFound } from 'next/navigation'

export default function ProductPage({ params }: { params: { id: string } }) {
  const product = products.find(p => p.id === params.id)

  if (!product) {
    notFound()
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <ProductDetail product={product} />
    </div>
  )
}

