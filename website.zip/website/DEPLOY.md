# Quick Deployment Guide

## Option 1: Deploy to Vercel (Recommended - Fastest)

Vercel is the easiest way to deploy Next.js projects. Follow these steps:

### Method A: Using Vercel CLI (Fastest)

1. Install Vercel CLI globally:
```bash
npm install -g vercel
```

2. Login to Vercel:
```bash
vercel login
```

3. Deploy your project:
```bash
vercel
```

4. Follow the prompts - it will ask you to link to an existing project or create a new one.

5. Your site will be live in seconds! You'll get a URL like: `https://your-project.vercel.app`

### Method B: Using Vercel Website (No CLI needed)

1. Go to [vercel.com](https://vercel.com)
2. Sign up/Login with GitHub
3. Click "Add New Project"
4. Import your Git repository (or drag and drop the project folder)
5. Vercel will auto-detect Next.js and deploy automatically
6. Your site will be live in 1-2 minutes!

## Option 2: Deploy to Netlify

1. Go to [netlify.com](https://netlify.com)
2. Sign up/Login
3. Drag and drop your project folder OR connect to Git
4. Build settings:
   - Build command: `npm run build`
   - Publish directory: `.next`
5. Deploy!

## Option 3: Deploy to GitHub Pages (via GitHub Actions)

If you want to use GitHub Pages, you'll need to configure it differently since Next.js requires server-side rendering.

## Quick Deploy Commands

### For Vercel:
```bash
npm install -g vercel
vercel
```

### For Netlify:
```bash
npm install -g netlify-cli
netlify deploy
```

## After Deployment

Once deployed, you'll get a live URL that you can share. The site will automatically update when you push changes to your Git repository (if connected).

