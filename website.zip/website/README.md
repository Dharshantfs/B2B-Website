# Bagify Brandify Studio - Ecommerce Website

A modern, full-featured ecommerce website built with Next.js, React, and TypeScript for selling premium bags and branding products.

## Features

- 🛍️ **Product Catalog**: Browse products by category with filtering
- 🛒 **Shopping Cart**: Add, remove, and update items with persistent storage
- 💳 **Checkout Process**: Complete checkout flow with form validation
- 📱 **Responsive Design**: Mobile-first design that works on all devices
- 🎨 **Modern UI**: Beautiful interface built with Tailwind CSS
- ⚡ **Fast Performance**: Optimized with Next.js 14

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **Icons**: React Icons
- **State Management**: React Context API

## Getting Started

### Prerequisites

- Node.js 18+ installed
- npm or yarn package manager

### Installation

1. Install dependencies:
```bash
npm install
```

2. Run the development server:
```bash
npm run dev
```

3. Open [http://localhost:3000](http://localhost:3000) in your browser

### Build for Production

```bash
npm run build
npm start
```

## Project Structure

```
├── app/                 # Next.js app directory
│   ├── page.tsx        # Home page
│   ├── products/       # Products pages
│   ├── cart/           # Shopping cart page
│   └── checkout/       # Checkout page
├── components/         # React components
│   ├── Navbar.tsx
│   ├── Footer.tsx
│   ├── ProductCard.tsx
│   └── ...
├── context/            # React context providers
│   └── CartContext.tsx
└── data/               # Static data
    └── products.ts
```

## Features in Detail

### Shopping Cart
- Add products to cart
- Update quantities
- Remove items
- Persistent storage (localStorage)
- Real-time total calculation

### Product Pages
- Product listing with category filters
- Individual product detail pages
- Featured products section
- Category browsing

### Checkout
- Shipping information form
- Payment information form
- Order summary
- Form validation

## Customization

### Adding Products
Edit `data/products.ts` to add or modify products.

### Styling
Modify `tailwind.config.js` to customize colors and theme.

### Pages
Add new pages in the `app/` directory following Next.js App Router conventions.

## License

This project is open source and available for use.

