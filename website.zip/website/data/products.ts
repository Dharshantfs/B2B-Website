export interface Product {
  id: string
  name: string
  description: string
  price: number
  image: string
  category: string
  categoryType: 'plain' | 'screen-printed' | 'full-customization'
  moq: number
  increment: number
  featured?: boolean
  inStock: boolean
}

export const products: Product[] = [
  // Ready To Ship Bags (Plain Bags)
  {
    id: '1',
    name: 'Plain Shopping Bag - Red',
    description: 'High-quality plain red shopping bag. Perfect for retail and promotional use. MOQ: 1000pcs',
    price: 0.50,
    image: '/images/plain-bags/red-bag.jpg',
    category: 'Ready To Ship Bags',
    categoryType: 'plain',
    moq: 1000,
    increment: 100,
    featured: true,
    inStock: true,
  },
  {
    id: '2',
    name: 'Plain Shopping Bag - Blue',
    description: 'Durable plain blue shopping bag. Ideal for various business needs. MOQ: 1000pcs',
    price: 0.50,
    image: '/images/plain-bags/blue-bag.jpg',
    category: 'Ready To Ship Bags',
    categoryType: 'plain',
    moq: 1000,
    increment: 100,
    featured: true,
    inStock: true,
  },
  {
    id: '3',
    name: 'Plain Shopping Bag - Yellow',
    description: 'Bright yellow plain shopping bag. Eye-catching and practical. MOQ: 1000pcs',
    price: 0.50,
    image: '/images/plain-bags/yellow-bag.jpg',
    category: 'Ready To Ship Bags',
    categoryType: 'plain',
    moq: 1000,
    increment: 100,
    featured: false,
    inStock: true,
  },
  {
    id: '4',
    name: 'Plain Shopping Bag - Green',
    description: 'Eco-friendly green plain shopping bag. Sustainable choice. MOQ: 1000pcs',
    price: 0.50,
    image: '/images/plain-bags/green-bag.jpg',
    category: 'Ready To Ship Bags',
    categoryType: 'plain',
    moq: 1000,
    increment: 100,
    featured: false,
    inStock: true,
  },
  // Screen Printed Bags
  {
    id: '5',
    name: 'Screen Printed Bag - Custom Logo',
    description: 'Screen printed bag with your custom logo. Upload your logo, choose size and color. MOQ: 1000pcs',
    price: 1.25,
    image: '/images/screen-printed-bags/screen-printed-1.jpg',
    category: 'Screen Printed Bags',
    categoryType: 'screen-printed',
    moq: 1000,
    increment: 100,
    featured: true,
    inStock: true,
  },
  {
    id: '6',
    name: 'Screen Printed D Cut Bag',
    description: 'D-cut screen printed bag with custom design. Professional printing quality. MOQ: 1000pcs',
    price: 1.50,
    image: '/images/screen-printed-bags/screen-printed-2.jpg',
    category: 'Screen Printed D Cut Bags',
    categoryType: 'screen-printed',
    moq: 1000,
    increment: 100,
    featured: true,
    inStock: true,
  },
  // Full Customization Bags
  {
    id: '7',
    name: 'Custom Bopp Box Bag - Sweet Series',
    description: 'Fully customizable BOPP box bag in sweet series design. Complete design freedom. MOQ: 5000pcs',
    price: 2.00,
    image: '/images/ready-to-ship/custom-1.jpg',
    category: 'Sweet Series Bags',
    categoryType: 'full-customization',
    moq: 5000,
    increment: 100,
    featured: true,
    inStock: true,
  },
  {
    id: '8',
    name: 'Custom Bopp Box Bag - Textile Jewelry',
    description: 'Premium BOPP box bag for textile and jewelry. High-end customization available. MOQ: 5000pcs',
    price: 2.50,
    image: '/images/ready-to-ship/custom-2.jpg',
    category: 'Textile Jewelry Bags',
    categoryType: 'full-customization',
    moq: 5000,
    increment: 100,
    featured: false,
    inStock: true,
  },
  {
    id: '9',
    name: 'Bopp D Cut Bag - Full Custom',
    description: 'Fully customizable BOPP D-cut bag. Complete design control. MOQ: 5000pcs',
    price: 2.25,
    image: '/images/ready-to-ship/custom-3.jpg',
    category: 'Bopp D Cut Bags',
    categoryType: 'full-customization',
    moq: 5000,
    increment: 100,
    featured: false,
    inStock: true,
  },
]

