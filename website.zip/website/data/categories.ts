export interface CategoryNode {
  id: string
  name: string
  slug: string
  children?: CategoryNode[]
}

export const categoryHierarchy: CategoryNode[] = [
  {
    id: 'ready-to-ship',
    name: 'Ready To Ship Bags',
    slug: 'ready-to-ship-bags',
  },
  {
    id: 'screen-printed',
    name: 'Screen Printed Bags',
    slug: 'screen-printed-bags',
  },
  {
    id: 'custom-printed-insides',
    name: 'Custom Printed Bags Insides',
    slug: 'custom-printed-bags-insides',
    children: [
      {
        id: 'bopp-box',
        name: 'Custom Bopp Box Bags',
        slug: 'custom-bopp-box-bags',
        children: [
          {
            id: 'sweet-series',
            name: 'Sweet Series Bags',
            slug: 'sweet-series-bags',
          },
          {
            id: 'textile-jewelry',
            name: 'Textile Jewelry Bags',
            slug: 'textile-jewelry-bags',
          },
        ],
      },
    ],
  },
  {
    id: 'custom-printed-d-cut',
    name: 'Custom Printed D Cut Bags',
    slug: 'custom-printed-d-cut-bags',
    children: [
      {
        id: 'screen-printed-d-cut',
        name: 'Screen Printed D Cut Bags',
        slug: 'screen-printed-d-cut-bags',
      },
      {
        id: 'bopp-d-cut',
        name: 'Bopp D Cut Bags',
        slug: 'bopp-d-cut-bags',
      },
    ],
  },
]

// Flatten categories for easy lookup
export function getAllCategorySlugs(): string[] {
  const slugs: string[] = []
  
  function traverse(node: CategoryNode) {
    slugs.push(node.slug)
    if (node.children) {
      node.children.forEach(traverse)
    }
  }
  
  categoryHierarchy.forEach(traverse)
  return slugs
}

// Get category type based on category slug
export function getCategoryType(category: string): 'plain' | 'screen-printed' | 'full-customization' {
  if (category.includes('plain') || category.includes('ready-to-ship')) {
    return 'plain'
  }
  if (category.includes('screen-printed')) {
    return 'screen-printed'
  }
  return 'full-customization'
}

// Get MOQ based on category type
export function getMOQ(categoryType: 'plain' | 'screen-printed' | 'full-customization'): number {
  switch (categoryType) {
    case 'plain':
      return 1000
    case 'screen-printed':
      return 1000
    case 'full-customization':
      return 5000
    default:
      return 1000
  }
}

