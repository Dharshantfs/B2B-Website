'use client'

import { useState, useEffect } from 'react'
import DesignUpload from './DesignUpload'

interface DesignSubmission {
  id: string
  customerEmail: string
  productId: string
  productName: string
  logo: string
  size: string
  color: string
  status: 'pending' | 'in-progress' | 'completed'
  designerUpload?: string
  submittedAt: string
  completedAt?: string
}

export default function DesignRequests() {
  const [requests, setRequests] = useState<DesignSubmission[]>([])
  const [selectedRequest, setSelectedRequest] = useState<DesignSubmission | null>(null)

  useEffect(() => {
    // Load all design submissions from all customers
    const allSubmissions: DesignSubmission[] = []
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i)
      if (key?.startsWith('designSubmissions_')) {
        const submissions = JSON.parse(localStorage.getItem(key) || '[]')
        allSubmissions.push(...submissions)
      }
    }
    setRequests(allSubmissions.sort((a, b) => 
      new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime()
    ))
  }, [])

  const handleStatusUpdate = (id: string, status: 'pending' | 'in-progress' | 'completed', designerUpload?: string) => {
    // Update in all customer storage
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i)
      if (key?.startsWith('designSubmissions_')) {
        const submissions: DesignSubmission[] = JSON.parse(localStorage.getItem(key) || '[]')
        const updated = submissions.map(s => 
          s.id === id ? { ...s, status, designerUpload, completedAt: status === 'completed' ? new Date().toISOString() : s.completedAt } : s
        )
        localStorage.setItem(key, JSON.stringify(updated))
      }
    }
    setRequests(prev => prev.map(r => 
      r.id === id ? { ...r, status, designerUpload, completedAt: status === 'completed' ? new Date().toISOString() : r.completedAt } : r
    ))
    setSelectedRequest(null)
  }

  if (requests.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold mb-4">Design Requests</h2>
        <p className="text-gray-600">No design requests at the moment.</p>
      </div>
    )
  }

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Design Requests</h2>
      {selectedRequest ? (
        <DesignUpload
          request={selectedRequest}
          onUpload={(url) => handleStatusUpdate(selectedRequest.id, 'completed', url)}
          onCancel={() => setSelectedRequest(null)}
          onStatusChange={(status) => handleStatusUpdate(selectedRequest.id, status)}
        />
      ) : (
        <div className="space-y-4">
          {requests.map((request) => (
            <div
              key={request.id}
              className="bg-white rounded-lg shadow-md p-6 border-l-4 border-primary-600"
            >
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div className="flex-1">
                  <h3 className="font-semibold text-lg mb-2">{request.productName}</h3>
                  <div className="space-y-1 text-sm text-gray-600">
                    <p>Customer: {request.customerEmail}</p>
                    <p>Size: {request.size}</p>
                    <p>Color: 
                      <span
                        className="inline-block w-4 h-4 rounded border ml-2"
                        style={{ backgroundColor: request.color }}
                      ></span>
                      {request.color}
                    </p>
                    <p>Submitted: {new Date(request.submittedAt).toLocaleDateString()}</p>
                  </div>
                  {request.logo && (
                    <div className="mt-3">
                      <p className="text-sm font-semibold mb-1">Customer Logo:</p>
                      <img
                        src={request.logo}
                        alt="Customer logo"
                        className="w-24 h-24 object-contain border rounded"
                      />
                    </div>
                  )}
                </div>
                <div className="flex flex-col items-end gap-2">
                  <span
                    className={`px-3 py-1 rounded-full text-sm font-semibold ${
                      request.status === 'completed'
                        ? 'bg-green-100 text-green-800'
                        : request.status === 'in-progress'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}
                  >
                    {request.status.charAt(0).toUpperCase() + request.status.slice(1).replace('-', ' ')}
                  </span>
                  {request.status !== 'completed' && (
                    <button
                      onClick={() => setSelectedRequest(request)}
                      className="bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition"
                    >
                      {request.status === 'pending' ? 'Start Design' : 'Upload Design'}
                    </button>
                  )}
                  {request.designerUpload && (
                    <div className="mt-2">
                      <p className="text-xs text-gray-600 mb-1">Your Design:</p>
                      <img
                        src={request.designerUpload}
                        alt="Designer design"
                        className="w-24 h-24 object-contain border rounded"
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

