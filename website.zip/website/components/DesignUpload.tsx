'use client'

import { useState, useRef } from 'react'
import { FiUpload, FiX, FiArrowLeft } from 'react-icons/fi'

interface DesignSubmission {
  id: string
  customerEmail: string
  productId: string
  productName: string
  logo: string
  size: string
  color: string
  status: 'pending' | 'in-progress' | 'completed'
  designerUpload?: string
  submittedAt: string
  completedAt?: string
}

interface DesignUploadProps {
  request: DesignSubmission
  onUpload: (url: string) => void
  onCancel: () => void
  onStatusChange: (status: 'pending' | 'in-progress' | 'completed') => void
}

export default function DesignUpload({ request, onUpload, onCancel, onStatusChange }: DesignUploadProps) {
  const [uploadedDesign, setUploadedDesign] = useState<string>(request.designerUpload || '')
  const [isUploading, setIsUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setIsUploading(true)
    const formData = new FormData()
    formData.append('file', file)
    formData.append('folder', 'designs/completed')

    try {
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      })

      const data = await response.json()
      if (data.success) {
        setUploadedDesign(data.url)
        onStatusChange('in-progress')
      } else {
        alert('Failed to upload design')
      }
    } catch (error) {
      console.error('Upload error:', error)
      alert('Failed to upload design')
    } finally {
      setIsUploading(false)
    }
  }

  const handleSubmit = () => {
    if (uploadedDesign) {
      onUpload(uploadedDesign)
      onStatusChange('completed')
    }
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">Upload Design for {request.productName}</h2>
        <button
          onClick={onCancel}
          className="text-gray-600 hover:text-gray-800"
        >
          <FiArrowLeft className="w-6 h-6" />
        </button>
      </div>

      <div className="mb-6 p-4 bg-gray-50 rounded-lg">
        <h3 className="font-semibold mb-2">Customer Requirements:</h3>
        <div className="space-y-1 text-sm text-gray-600">
          <p>Size: {request.size}</p>
          <p>Color: 
            <span
              className="inline-block w-4 h-4 rounded border ml-2"
              style={{ backgroundColor: request.color }}
            ></span>
            {request.color}
          </p>
          {request.logo && (
            <div className="mt-2">
              <p className="font-semibold">Customer Logo:</p>
              <img
                src={request.logo}
                alt="Customer logo"
                className="w-32 h-32 object-contain border rounded mt-2"
              />
            </div>
          )}
        </div>
      </div>

      <div className="mb-6">
        <label className="block text-sm font-semibold mb-2">Upload Your Design</label>
        {uploadedDesign ? (
          <div className="relative">
            <img
              src={uploadedDesign}
              alt="Uploaded design"
              className="w-full max-w-md h-auto object-contain border rounded-lg"
            />
            <button
              type="button"
              onClick={() => {
                setUploadedDesign('')
                fileInputRef.current?.click()
              }}
              className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-2 hover:bg-red-600"
            >
              <FiX className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-primary-600 transition"
          >
            <FiUpload className="mx-auto text-4xl text-gray-400 mb-2" />
            <p className="text-gray-600">Click to upload design</p>
            <p className="text-xs text-gray-400 mt-1">PNG, JPG up to 10MB</p>
          </div>
        )}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileUpload}
          className="hidden"
          disabled={isUploading}
        />
        {isUploading && <p className="text-sm text-gray-500 mt-2">Uploading...</p>}
      </div>

      <div className="flex space-x-4">
        <button
          onClick={handleSubmit}
          disabled={!uploadedDesign}
          className="flex-1 bg-primary-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-primary-700 transition disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          Submit Design to Customer
        </button>
        <button
          onClick={onCancel}
          className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition"
        >
          Cancel
        </button>
      </div>
    </div>
  )
}

