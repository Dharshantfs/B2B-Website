'use client'

import Link from 'next/link'
import { useCart } from '@/context/CartContext'
import { useAuth } from '@/context/AuthContext'
import { FiShoppingCart, FiMenu, FiX, FiUser, FiLogOut } from 'react-icons/fi'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

export default function Navbar() {
  const { getTotalItems } = useCart()
  const { user, logout, isAuthenticated } = useAuth()
  const router = useRouter()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const totalItems = getTotalItems()

  const handleLogout = () => {
    logout()
    router.push('/')
  }

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="text-2xl font-bold text-primary-600">
            Bagify Brandify
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-700 hover:text-primary-600 transition">
              Home
            </Link>
            <Link href="/products" className="text-gray-700 hover:text-primary-600 transition">
              Products
            </Link>
            <Link href="/about" className="text-gray-700 hover:text-primary-600 transition">
              About
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-primary-600 transition">
              Contact
            </Link>
            {isAuthenticated ? (
              <>
                {user?.role === 'designer' && (
                  <Link href="/designer/dashboard" className="text-gray-700 hover:text-primary-600 transition">
                    Designer Dashboard
                  </Link>
                )}
                {user?.role === 'admin' && (
                  <Link href="/admin/dashboard" className="text-gray-700 hover:text-primary-600 transition">
                    Admin Dashboard
                  </Link>
                )}
                {user?.role === 'customer' && (
                  <Link href="/dashboard" className="text-gray-700 hover:text-primary-600 transition">
                    Dashboard
                  </Link>
                )}
                <div className="flex items-center space-x-2">
                  <FiUser className="text-gray-700" />
                  <span className="text-sm text-gray-700">{user?.email}</span>
                </div>
                <button
                  onClick={handleLogout}
                  className="text-gray-700 hover:text-primary-600 transition flex items-center space-x-1"
                >
                  <FiLogOut />
                  <span>Logout</span>
                </button>
              </>
            ) : (
              <Link href="/login" className="text-gray-700 hover:text-primary-600 transition">
                Login
              </Link>
            )}
            <Link href="/cart" className="relative">
              <FiShoppingCart className="text-2xl text-gray-700 hover:text-primary-600 transition" />
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-primary-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-gray-700"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <FiX size={24} /> : <FiMenu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 space-y-4">
            <Link href="/" className="block text-gray-700 hover:text-primary-600">
              Home
            </Link>
            <Link href="/products" className="block text-gray-700 hover:text-primary-600">
              Products
            </Link>
            <Link href="/about" className="block text-gray-700 hover:text-primary-600">
              About
            </Link>
            <Link href="/contact" className="block text-gray-700 hover:text-primary-600">
              Contact
            </Link>
            {isAuthenticated ? (
              <>
                {user?.role === 'designer' && (
                  <Link href="/designer/dashboard" className="block text-gray-700 hover:text-primary-600">
                    Designer Dashboard
                  </Link>
                )}
                {user?.role === 'admin' && (
                  <Link href="/admin/dashboard" className="block text-gray-700 hover:text-primary-600">
                    Admin Dashboard
                  </Link>
                )}
                {user?.role === 'customer' && (
                  <Link href="/dashboard" className="block text-gray-700 hover:text-primary-600">
                    Dashboard
                  </Link>
                )}
                <div className="flex items-center space-x-2 text-gray-700">
                  <FiUser />
                  <span className="text-sm">{user?.email}</span>
                </div>
                <button
                  onClick={handleLogout}
                  className="flex items-center space-x-2 text-gray-700 hover:text-primary-600 w-full text-left"
                >
                  <FiLogOut />
                  <span>Logout</span>
                </button>
              </>
            ) : (
              <Link href="/login" className="block text-gray-700 hover:text-primary-600">
                Login
              </Link>
            )}
            <Link href="/cart" className="flex items-center space-x-2 text-gray-700 hover:text-primary-600">
              <FiShoppingCart />
              <span>Cart {totalItems > 0 && `(${totalItems})`}</span>
            </Link>
          </div>
        )}
      </div>
    </nav>
  )
}

