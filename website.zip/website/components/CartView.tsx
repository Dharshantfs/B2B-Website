'use client'

import { useCart } from '@/context/CartContext'
import { FiTrash2 } from 'react-icons/fi'
import Link from 'next/link'
import QuantitySelector from './QuantitySelector'

export default function CartView() {
  const { cart, removeFromCart, updateQuantity, getTotalPrice, clearCart } = useCart()

  if (cart.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-xl text-gray-600 mb-4">Your cart is empty</p>
        <Link
          href="/products"
          className="inline-block bg-primary-600 text-white px-6 py-3 rounded-lg hover:bg-primary-700 transition"
        >
          Continue Shopping
        </Link>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-4">
        {cart.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-lg shadow-md p-6 flex flex-col md:flex-row gap-4"
          >
            <div className="w-full md:w-32 h-32 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.currentTarget.style.display = 'none'
                }}
              />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold mb-2">{item.name}</h3>
              <p className="text-primary-600 font-bold mb-2">
                ${item.price.toFixed(2)} per piece
              </p>
              <div className="mb-4">
                <QuantitySelector
                  moq={item.moq}
                  increment={100}
                  value={item.quantity}
                  onChange={(qty) => updateQuantity(item.id, qty)}
                />
              </div>
              <button
                onClick={() => removeFromCart(item.id)}
                className="text-red-500 hover:text-red-700 transition flex items-center space-x-2"
              >
                <FiTrash2 />
                <span>Remove</span>
              </button>
            </div>
            <div className="text-right md:text-left md:ml-auto">
              <p className="text-sm text-gray-500 mb-1">Total</p>
              <p className="text-2xl font-bold text-primary-600">
                ${(item.price * item.quantity).toFixed(2)}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                {item.quantity.toLocaleString()}pcs
              </p>
            </div>
          </div>
        ))}
      </div>
      <div className="lg:col-span-1">
        <div className="bg-white rounded-lg shadow-md p-6 sticky top-24">
          <h2 className="text-2xl font-bold mb-6">Order Summary</h2>
          <div className="space-y-4 mb-6">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>${getTotalPrice().toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Shipping</span>
              <span>Free</span>
            </div>
            <div className="border-t pt-4 flex justify-between text-xl font-bold">
              <span>Total</span>
              <span>${getTotalPrice().toFixed(2)}</span>
            </div>
          </div>
          <Link
            href="/checkout"
            className="block w-full bg-primary-600 text-white text-center px-6 py-3 rounded-lg hover:bg-primary-700 transition mb-4"
          >
            Proceed to Checkout
          </Link>
          <Link
            href="/products"
            className="block w-full text-center text-gray-600 hover:text-gray-800 transition"
          >
            Continue Shopping
          </Link>
          <button
            onClick={clearCart}
            className="w-full mt-4 text-red-500 hover:text-red-700 transition"
          >
            Clear Cart
          </button>
        </div>
      </div>
    </div>
  )
}

