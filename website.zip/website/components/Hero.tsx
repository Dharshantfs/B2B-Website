import Link from 'next/link'
import { FiArrowRight } from 'react-icons/fi'

export default function Hero() {
  return (
    <section className="relative bg-gradient-to-r from-primary-600 to-primary-800 text-white">
      <div className="container mx-auto px-4 py-24 md:py-32">
        <div className="max-w-3xl">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Premium Bags & Branding Products
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-100">
            Discover our curated collection of high-quality bags and branding essentials
            designed for the modern professional.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link
              href="/products"
              className="bg-white text-primary-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition flex items-center justify-center"
            >
              Shop Now
              <FiArrowRight className="ml-2" />
            </Link>
            <Link
              href="/about"
              className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-primary-600 transition"
            >
              Learn More
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

