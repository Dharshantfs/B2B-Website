'use client'

import { useState, useEffect } from 'react'
import { useAuth } from '@/context/AuthContext'

interface DesignSubmission {
  id: string
  customerEmail: string
  productId: string
  productName: string
  logo: string
  size: string
  color: string
  status: 'pending' | 'in-progress' | 'completed'
  designerUpload?: string
  submittedAt: string
  completedAt?: string
}

export default function DesignSubmissions() {
  const { user } = useAuth()
  const [submissions, setSubmissions] = useState<DesignSubmission[]>([])

  useEffect(() => {
    if (user?.email) {
      const saved = localStorage.getItem(`designSubmissions_${user.email}`)
      if (saved) {
        setSubmissions(JSON.parse(saved))
      }
    }
  }, [user])

  if (submissions.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold mb-4">Design Submissions</h2>
        <p className="text-gray-600">No design submissions yet.</p>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-6">Design Submissions</h2>
      <div className="space-y-4">
        {submissions.map((submission) => (
          <div
            key={submission.id}
            className="border rounded-lg p-4 hover:shadow-md transition"
          >
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex-1">
                <h3 className="font-semibold text-lg mb-2">{submission.productName}</h3>
                <div className="space-y-1 text-sm text-gray-600">
                  <p>Size: {submission.size}</p>
                  <p>Color: 
                    <span
                      className="inline-block w-4 h-4 rounded border ml-2"
                      style={{ backgroundColor: submission.color }}
                    ></span>
                    {submission.color}
                  </p>
                  <p>Submitted: {new Date(submission.submittedAt).toLocaleDateString()}</p>
                </div>
                {submission.logo && (
                  <img
                    src={submission.logo}
                    alt="Logo"
                    className="w-24 h-24 object-contain mt-2 border rounded"
                  />
                )}
              </div>
              <div className="flex flex-col items-end">
                <span
                  className={`px-3 py-1 rounded-full text-sm font-semibold ${
                    submission.status === 'completed'
                      ? 'bg-green-100 text-green-800'
                      : submission.status === 'in-progress'
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}
                >
                  {submission.status.charAt(0).toUpperCase() + submission.status.slice(1).replace('-', ' ')}
                </span>
                {submission.designerUpload && (
                  <div className="mt-4">
                    <p className="text-sm text-gray-600 mb-2">Designer's Design:</p>
                    <img
                      src={submission.designerUpload}
                      alt="Designer design"
                      className="w-32 h-32 object-contain border rounded"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

