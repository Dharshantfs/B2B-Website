import Link from 'next/link'

const categories = [
  { name: 'Plain Bags', image: '/images/plain-bags/placeholder.jpg', slug: 'plain-bags' },
  { name: 'Screen Printed Bags', image: '/images/screen-printed-bags/placeholder.jpg', slug: 'screen-printed-bags' },
  { name: 'Full Customization Bags', image: '/images/ready-to-ship/placeholder.jpg', slug: 'full-customization-bags' },
]

export default function Categories() {
  return (
    <section className="container mx-auto px-4 py-16">
      <h2 className="text-3xl font-bold text-center mb-12">Shop by Category</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {categories.map((category) => (
          <Link
            key={category.slug}
            href={`/products?category=${category.slug}`}
            className="group relative overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition"
          >
            <div className="aspect-square bg-gray-200 flex items-center justify-center">
              <img
                src={category.image}
                alt={category.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                onError={(e) => {
                  e.currentTarget.style.display = 'none'
                  e.currentTarget.parentElement!.innerHTML = '<div class="w-full h-full flex items-center justify-center text-gray-400 text-xl">' + category.name + '</div>'
                }}
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
              <h3 className="text-white text-xl font-semibold p-6">
                {category.name}
              </h3>
            </div>
          </Link>
        ))}
      </div>
    </section>
  )
}

