'use client'

import { Product } from '@/data/products'
import { useCart } from '@/context/CartContext'
import { FiShoppingCart, FiArrowLeft } from 'react-icons/fi'
import Link from 'next/link'
import { useState } from 'react'
import QuantitySelector from './QuantitySelector'
import DesignCustomizer from './DesignCustomizer'

interface ProductDetailProps {
  product: Product
}

export default function ProductDetail({ product }: ProductDetailProps) {
  const { addToCart } = useCart()
  const [quantity, setQuantity] = useState(product.moq)
  const [showDesigner, setShowDesigner] = useState(false)
  const [designData, setDesignData] = useState<{ logo: string; size: string; color: string } | null>(null)

  const isScreenPrinted = product.categoryType === 'screen-printed'

  const handleDesignSubmit = (design: { logo: string; size: string; color: string }) => {
    setDesignData(design)
    setShowDesigner(false)
  }

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      moq: product.moq,
      categoryType: product.categoryType,
      quantity: quantity,
      designData: designData || undefined,
    })
  }

  return (
    <div>
      <Link
        href="/products"
        className="inline-flex items-center text-primary-600 hover:text-primary-700 mb-6"
      >
        <FiArrowLeft className="mr-2" />
        Back to Products
      </Link>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="relative aspect-square">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover rounded-lg"
          />
        </div>
        <div>
          <h1 className="text-4xl font-bold mb-4">{product.name}</h1>
          <p className="text-3xl font-bold text-primary-600 mb-6">
            ${product.price.toFixed(2)}
          </p>
          <p className="text-gray-700 mb-8 leading-relaxed">
            {product.description}
          </p>
          {isScreenPrinted && !showDesigner && !designData && (
            <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-blue-800 mb-3">
                This product requires custom design. Please upload your logo and select size/color.
              </p>
              <button
                type="button"
                onClick={() => setShowDesigner(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
              >
                Customize Design
              </button>
            </div>
          )}
          {isScreenPrinted && showDesigner && (
            <div className="mb-6">
              <DesignCustomizer
                onDesignSubmit={handleDesignSubmit}
                onCancel={() => setShowDesigner(false)}
              />
            </div>
          )}
          {isScreenPrinted && designData && !showDesigner && (
            <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-sm text-green-800 mb-2 font-semibold">Design Added:</p>
              <div className="space-y-1 text-sm text-green-700">
                <p>Size: {designData.size}</p>
                <p>Color: <span className="inline-block w-4 h-4 rounded border" style={{ backgroundColor: designData.color }}></span> {designData.color}</p>
                {designData.logo && <img src={designData.logo} alt="Logo" className="w-16 h-16 object-contain mt-2" />}
              </div>
              <button
                type="button"
                onClick={() => {
                  setDesignData(null)
                  setShowDesigner(true)
                }}
                className="mt-2 text-sm text-blue-600 hover:text-blue-800"
              >
                Change Design
              </button>
            </div>
          )}
          <div className="mb-6">
            <label className="block text-sm font-semibold mb-2">Quantity</label>
            <QuantitySelector
              moq={product.moq}
              increment={product.increment}
              value={quantity}
              onChange={setQuantity}
              disabled={!product.inStock || (isScreenPrinted && !designData)}
            />
          </div>
          <button
            onClick={handleAddToCart}
            disabled={!product.inStock || (isScreenPrinted && !designData)}
            className="w-full bg-primary-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-primary-700 transition flex items-center justify-center space-x-2 disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            <FiShoppingCart />
            <span>Add to Cart</span>
          </button>
          {!product.inStock && (
            <p className="text-red-500 text-sm mt-2 text-center">Out of Stock</p>
          )}
          <div className="mt-8 pt-8 border-t">
            <h3 className="font-semibold mb-2">Product Details</h3>
            <ul className="space-y-2 text-gray-600">
              <li>Category: {product.category}</li>
              <li>Category Type: {product.categoryType.replace('-', ' ')}</li>
              <li>Minimum Order Quantity: {product.moq.toLocaleString()}pcs</li>
              <li>Increment: {product.increment}pcs</li>
              <li>Status: {product.inStock ? 'In Stock' : 'Out of Stock'}</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

