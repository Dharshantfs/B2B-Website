'use client'

import { products } from '@/data/products'
import ProductCard from './ProductCard'
import { useState, useEffect } from 'react'
import { useSearchParams } from 'next/navigation'
import CategoryTree from './CategoryTree'
import { categoryHierarchy, getAllCategorySlugs } from '@/data/categories'

export default function ProductGrid() {
  const searchParams = useSearchParams()
  const categoryParam = searchParams.get('category')
  const [selectedCategory, setSelectedCategory] = useState<string>(categoryParam || 'All')

  useEffect(() => {
    if (categoryParam) {
      setSelectedCategory(categoryParam)
    }
  }, [categoryParam])

  // Filter products based on selected category
  const filteredProducts = selectedCategory === 'All'
    ? products
    : products.filter(p => {
        // Check if product category matches selected category or any parent category
        const categorySlugs = getAllCategorySlugs()
        if (categorySlugs.includes(selectedCategory)) {
          return p.category.toLowerCase().includes(selectedCategory.toLowerCase()) ||
                 selectedCategory.toLowerCase().includes(p.category.toLowerCase())
        }
        return p.category === selectedCategory
      })

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
      <div className="lg:col-span-1">
        <CategoryTree
          categories={categoryHierarchy}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
        />
      </div>
      <div className="lg:col-span-3">
        <div className="mb-6">
          <h2 className="text-2xl font-bold mb-2">
            {selectedCategory === 'All' ? 'All Products' : selectedCategory.replace(/-/g, ' ')}
          </h2>
          <p className="text-gray-600">
            {filteredProducts.length} product{filteredProducts.length !== 1 ? 's' : ''} found
          </p>
        </div>
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-600 text-lg">No products found in this category.</p>
          </div>
        )}
      </div>
    </div>
  )
}

