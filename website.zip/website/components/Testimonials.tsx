const testimonials = [
  {
    name: 'Sarah Johnson',
    role: 'Business Professional',
    content: 'The quality of these bags is exceptional. I\'ve been using my leather backpack for months and it still looks brand new!',
    rating: 5,
  },
  {
    name: 'Michael Chen',
    role: 'Designer',
    content: 'Perfect blend of style and functionality. The design is modern and the materials are top-notch.',
    rating: 5,
  },
  {
    name: 'Emily Davis',
    role: 'Travel Enthusiast',
    content: 'My travel duffel has been through multiple trips and shows no signs of wear. Highly recommend!',
    rating: 5,
  },
]

export default function Testimonials() {
  return (
    <section className="container mx-auto px-4 py-16">
      <h2 className="text-3xl font-bold text-center mb-12">What Our Customers Say</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {testimonials.map((testimonial, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex mb-4">
              {[...Array(testimonial.rating)].map((_, i) => (
                <span key={i} className="text-yellow-400 text-xl">★</span>
              ))}
            </div>
            <p className="text-gray-700 mb-4 italic">"{testimonial.content}"</p>
            <div>
              <p className="font-semibold">{testimonial.name}</p>
              <p className="text-sm text-gray-600">{testimonial.role}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

