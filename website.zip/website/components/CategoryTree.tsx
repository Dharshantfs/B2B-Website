'use client'

import { useState } from 'react'
import { CategoryNode } from '@/data/categories'
import { FiChevronDown, FiChevronRight } from 'react-icons/fi'

interface CategoryTreeProps {
  categories: CategoryNode[]
  selectedCategory: string
  onSelectCategory: (slug: string) => void
}

export default function CategoryTree({ categories, selectedCategory, onSelectCategory }: CategoryTreeProps) {
  const [expanded, setExpanded] = useState<Set<string>>(new Set())

  const toggleExpand = (id: string) => {
    const newExpanded = new Set(expanded)
    if (newExpanded.has(id)) {
      newExpanded.delete(id)
    } else {
      newExpanded.add(id)
    }
    setExpanded(newExpanded)
  }

  const renderCategory = (category: CategoryNode, level: number = 0) => {
    const hasChildren = category.children && category.children.length > 0
    const isExpanded = expanded.has(category.id)
    const isSelected = selectedCategory === category.slug

    return (
      <div key={category.id} className="mb-1">
        <div
          className={`flex items-center py-2 px-3 rounded-lg cursor-pointer transition ${
            isSelected
              ? 'bg-primary-600 text-white'
              : 'hover:bg-gray-100 text-gray-700'
          }`}
          style={{ paddingLeft: `${level * 20 + 12}px` }}
        >
          {hasChildren && (
            <button
              onClick={(e) => {
                e.stopPropagation()
                toggleExpand(category.id)
              }}
              className="mr-2 p-1 hover:bg-gray-200 rounded"
            >
              {isExpanded ? (
                <FiChevronDown className="w-4 h-4" />
              ) : (
                <FiChevronRight className="w-4 h-4" />
              )}
            </button>
          )}
          {!hasChildren && <span className="w-6 mr-2" />}
          <button
            onClick={() => onSelectCategory(category.slug)}
            className="flex-1 text-left"
          >
            {category.name}
          </button>
        </div>
        {hasChildren && isExpanded && (
          <div className="ml-4">
            {category.children!.map((child) => renderCategory(child, level + 1))}
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h3 className="font-semibold text-lg mb-4">Categories</h3>
      <div>
        <button
          onClick={() => onSelectCategory('All')}
          className={`w-full text-left py-2 px-3 rounded-lg transition ${
            selectedCategory === 'All'
              ? 'bg-primary-600 text-white'
              : 'hover:bg-gray-100 text-gray-700'
          }`}
        >
          All Products
        </button>
        {categories.map((category) => renderCategory(category))}
      </div>
    </div>
  )
}

