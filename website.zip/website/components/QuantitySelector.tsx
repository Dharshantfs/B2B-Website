'use client'

import { useState, useEffect } from 'react'
import { FiPlus, FiMinus } from 'react-icons/fi'

interface QuantitySelectorProps {
  moq: number
  increment: number
  value: number
  onChange: (quantity: number) => void
  disabled?: boolean
}

export default function QuantitySelector({
  moq,
  increment,
  value,
  onChange,
  disabled = false,
}: QuantitySelectorProps) {
  const [inputValue, setInputValue] = useState(value.toString())
  const [error, setError] = useState('')

  useEffect(() => {
    setInputValue(value.toString())
  }, [value])

  const validateAndSetQuantity = (newQuantity: number) => {
    if (newQuantity < moq) {
      setError(`Minimum order quantity is ${moq.toLocaleString()}pcs`)
      onChange(moq)
      return
    }
    setError('')
    onChange(newQuantity)
  }

  const handleDecrease = () => {
    if (value <= moq) {
      validateAndSetQuantity(moq)
      return
    }
    const newQuantity = value - increment
    validateAndSetQuantity(Math.max(moq, newQuantity))
  }

  const handleIncrease = () => {
    const newQuantity = value + increment
    validateAndSetQuantity(newQuantity)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const input = e.target.value
    setInputValue(input)
    
    if (input === '') {
      setError('')
      return
    }

    const numValue = parseInt(input, 10)
    if (isNaN(numValue)) {
      setError('Please enter a valid number')
      return
    }

    if (numValue < moq) {
      setError(`Minimum order quantity is ${moq.toLocaleString()}pcs`)
      validateAndSetQuantity(moq)
      return
    }

    setError('')
    validateAndSetQuantity(numValue)
  }

  const handleBlur = () => {
    const numValue = parseInt(inputValue, 10)
    if (isNaN(numValue) || numValue < moq) {
      validateAndSetQuantity(moq)
    }
  }

  return (
    <div className="w-full">
      <div className="flex items-center space-x-2 mb-2">
        <button
          type="button"
          onClick={handleDecrease}
          disabled={disabled || value <= moq}
          className="bg-gray-200 hover:bg-gray-300 disabled:bg-gray-100 disabled:cursor-not-allowed disabled:text-gray-400 p-2 rounded-lg transition flex items-center justify-center"
        >
          <FiMinus className="w-4 h-4" />
        </button>
        <div className="flex-1">
          <input
            type="number"
            value={inputValue}
            onChange={handleInputChange}
            onBlur={handleBlur}
            disabled={disabled}
            min={moq}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg text-center text-lg font-semibold focus:outline-none focus:ring-2 focus:ring-primary-600 disabled:bg-gray-100"
          />
          <p className="text-xs text-gray-500 mt-1 text-center">pcs</p>
        </div>
        <button
          type="button"
          onClick={handleIncrease}
          disabled={disabled}
          className="bg-gray-200 hover:bg-gray-300 disabled:bg-gray-100 disabled:cursor-not-allowed p-2 rounded-lg transition flex items-center justify-center"
        >
          <FiPlus className="w-4 h-4" />
        </button>
      </div>
      {error && (
        <p className="text-red-500 text-sm mt-1">{error}</p>
      )}
      <div className="flex items-center justify-center mt-2">
        <span className="text-xs text-gray-600 bg-yellow-100 px-2 py-1 rounded">
          MOQ: {moq.toLocaleString()}pcs | Increment: {increment}pcs
        </span>
      </div>
    </div>
  )
}

