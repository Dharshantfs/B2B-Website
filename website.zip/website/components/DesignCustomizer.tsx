'use client'

import { useState, useRef } from 'react'
import { FiUpload, FiX } from 'react-icons/fi'

interface DesignCustomizerProps {
  onDesignSubmit: (design: { logo: string; size: string; color: string }) => void
  onCancel?: () => void
}

export default function DesignCustomizer({ onDesignSubmit, onCancel }: DesignCustomizerProps) {
  const [logo, setLogo] = useState<string>('')
  const [size, setSize] = useState('')
  const [color, setColor] = useState('#000000')
  const [isUploading, setIsUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const sizes = [
    'Small (8" x 10")',
    'Medium (10" x 12")',
    'Large (12" x 14")',
    'X-Large (14" x 16")',
  ]

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setIsUploading(true)
    const formData = new FormData()
    formData.append('file', file)
    formData.append('folder', 'designs/submitted')

    try {
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      })

      const data = await response.json()
      if (data.success) {
        setLogo(data.url)
      } else {
        alert('Failed to upload logo')
      }
    } catch (error) {
      console.error('Upload error:', error)
      alert('Failed to upload logo')
    } finally {
      setIsUploading(false)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!logo || !size || !color) {
      alert('Please fill in all design details')
      return
    }
    onDesignSubmit({ logo, size, color })
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-xl font-bold mb-6">Customize Your Design</h3>
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Logo Upload */}
        <div>
          <label className="block text-sm font-semibold mb-2">Upload Logo</label>
          {logo ? (
            <div className="relative">
              <img
                src={logo}
                alt="Uploaded logo"
                className="w-32 h-32 object-contain border rounded-lg"
              />
              <button
                type="button"
                onClick={() => setLogo('')}
                className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
              >
                <FiX className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-primary-600 transition"
            >
              <FiUpload className="mx-auto text-4xl text-gray-400 mb-2" />
              <p className="text-gray-600">Click to upload logo</p>
              <p className="text-xs text-gray-400 mt-1">PNG, JPG up to 5MB</p>
            </div>
          )}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
            disabled={isUploading}
          />
          {isUploading && <p className="text-sm text-gray-500 mt-2">Uploading...</p>}
        </div>

        {/* Size Selection */}
        <div>
          <label className="block text-sm font-semibold mb-2">Bag Size</label>
          <select
            value={size}
            onChange={(e) => setSize(e.target.value)}
            required
            className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-600"
          >
            <option value="">Select size</option>
            {sizes.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        {/* Color Selection */}
        <div>
          <label className="block text-sm font-semibold mb-2">Bag Color</label>
          <div className="flex items-center space-x-4">
            <input
              type="color"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              className="w-16 h-16 border rounded-lg cursor-pointer"
            />
            <input
              type="text"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              placeholder="#000000"
              className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-600"
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-4">
          <button
            type="submit"
            className="flex-1 bg-primary-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-primary-700 transition"
          >
            Save Design
          </button>
          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition"
            >
              Cancel
            </button>
          )}
        </div>
      </form>
    </div>
  )
}

