import { products } from '@/data/products'
import ProductCard from './ProductCard'
import Link from 'next/link'
import { FiArrowRight } from 'react-icons/fi'

export default function FeaturedProducts() {
  const featuredProducts = products.filter(p => p.featured).slice(0, 4)

  return (
    <section className="container mx-auto px-4 py-16 bg-gray-50">
      <div className="flex items-center justify-between mb-12">
        <h2 className="text-3xl font-bold">Featured Products</h2>
        <Link
          href="/products"
          className="text-primary-600 hover:text-primary-700 font-semibold flex items-center"
        >
          View All
          <FiArrowRight className="ml-2" />
        </Link>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {featuredProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  )
}

