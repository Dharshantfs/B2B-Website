'use client'

import Link from 'next/link'
import { Product } from '@/data/products'
import { useCart } from '@/context/CartContext'
import { FiShoppingCart } from 'react-icons/fi'
import { useState } from 'react'
import QuantitySelector from './QuantitySelector'

interface ProductCardProps {
  product: Product
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart()
  const [quantity, setQuantity] = useState(product.moq)
  const [showQuantitySelector, setShowQuantitySelector] = useState(false)

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault()
    if (!showQuantitySelector) {
      setShowQuantitySelector(true)
      return
    }
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      moq: product.moq,
      categoryType: product.categoryType,
      quantity: quantity,
      designData: undefined,
    })
  }

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition group">
      <Link href={`/products/${product.id}`}>
        <div className="relative aspect-square overflow-hidden bg-gray-100">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
            onError={(e) => {
              e.currentTarget.style.display = 'none'
            }}
          />
          {product.featured && (
            <span className="absolute top-4 left-4 bg-primary-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
              Featured
            </span>
          )}
          <div className="absolute top-4 right-4 bg-yellow-400 text-black px-2 py-1 rounded text-xs font-semibold">
            MOQ: {product.moq.toLocaleString()}pcs
          </div>
        </div>
      </Link>
      <div className="p-6">
        <Link href={`/products/${product.id}`}>
          <h3 className="text-xl font-semibold mb-2 hover:text-primary-600 transition">
            {product.name}
          </h3>
        </Link>
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
          {product.description}
        </p>
        <div className="mb-4">
          <span className="text-2xl font-bold text-primary-600">
            ${product.price.toFixed(2)}
          </span>
          <span className="text-gray-500 text-sm ml-2">per piece</span>
        </div>
        {showQuantitySelector ? (
          <div className="mb-4">
            <QuantitySelector
              moq={product.moq}
              increment={product.increment}
              value={quantity}
              onChange={setQuantity}
              disabled={!product.inStock}
            />
          </div>
        ) : null}
        <button
          onClick={handleAddToCart}
          disabled={!product.inStock}
          className="w-full bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition flex items-center justify-center space-x-2 disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          <FiShoppingCart />
          <span>{showQuantitySelector ? 'Add to Cart' : 'Select Quantity'}</span>
        </button>
        {!product.inStock && (
          <p className="text-red-500 text-sm mt-2 text-center">Out of Stock</p>
        )}
      </div>
    </div>
  )
}

