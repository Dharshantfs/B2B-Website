'use client'

import React, { createContext, useContext, useState, useEffect } from 'react'

export type UserRole = 'customer' | 'designer' | 'admin'

export interface User {
  email: string
  role: UserRole
  name?: string
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  isAuthenticated: boolean
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Load user from localStorage on mount
    const savedUser = localStorage.getItem('user')
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser))
      } catch (e) {
        console.error('Failed to parse saved user', e)
      }
    }
    setIsLoading(false)
  }, [])

  const getRoleFromEmail = (email: string): UserRole => {
    const domain = email.split('@')[1]?.toLowerCase()
    if (domain === 'designer.com') {
      return 'designer'
    }
    if (domain === 'admin.com') {
      return 'admin'
    }
    return 'customer'
  }

  const login = async (email: string, password: string): Promise<boolean> => {
    // In a real app, this would call an API
    // For now, we'll do a simple check (any password works for demo)
    if (!email || !password) {
      return false
    }

    const role = getRoleFromEmail(email)
    const userData: User = {
      email,
      role,
      name: email.split('@')[0],
    }

    setUser(userData)
    localStorage.setItem('user', JSON.stringify(userData))
    return true
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('user')
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        logout,
        isAuthenticated: !!user,
        isLoading,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

